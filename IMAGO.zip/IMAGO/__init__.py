def classFactory(iface):
    from .imago import IMAGO
    return IMAGO(iface)
